import * as React from 'react';
import { Text, View, StyleSheet, TextInput, Button, Image} from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
    <Image style={styles.logo} source={require('./assets/images.jpg')}> </Image>
    <Text>  USUÁRIO:  </Text>
    <TextInput style={styles.caixatxt} placeholder= "Nome"
    style1= {styles.textinput_Style}
    underlineColorAndroid="tranparent"
     /> 
     <Text> SENHA </Text>
     <TextInput style={styles.caixatxt} styles={styles.caixatxt} placeholder= "Senha"
    style1= {styles.textinput_Style}
    underlineColorAndroid="tranparent" />
     <Button
     title = "Login"
     color = '#0000ff'
     />
<Button
     title = "registro"
     color = ''
     />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#660000',
    padding: 8,
  },
  caixatxt: {
    height:30,
    margin:12,
    borderWidth: 1,
    padding: 10,
    backgroundColor: '#ffffff'
  },
});
